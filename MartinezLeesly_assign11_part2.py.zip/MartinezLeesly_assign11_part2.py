num_apps=0
class Smartphone:
    global num_apps
    def __init__(self, capacity, name):
        self.capacity = capacity
        self.name = name
        self.apps = {}
        self.get_available_space = capacity
        self.report()
        

    def add_app(self, appname, appsize):
        global num_apps
        if appname in self.apps:
            print(appname, "is already installed")
        elif appsize > self.get_available_space:
            print("Cannot install app, no available space")
        else:
            self.apps[appname] = appsize
            self.get_available_space -= appsize
            num_apps += 1

    def remove_app(self, appname):
        global num_apps
        if appname not in self.apps:
            print(appname, "is not in apps")
        else:
            appsize = self.apps[appname]
            del self.apps[appname]
            self.get_available_space += appsize
            num_apps -= 1
            print("App removed:", appname)

    def has_app(self, appname):
        return appname in self.apps

    def get_available_space(self):
        
        return self.get_available_space

    def report(self):
        global num_apps
        print("Name:", self.name)
        used_space = sum(self.apps.values())
        print("Capacity:", used_space, "out of", self.capacity, "GB")
        print("Available space:", self.get_available_space)
        num_apps = len(self.apps)
        print("Apps installed:", num_apps)
        if num_apps > 0:
            print("Installed apps:")
            for appname, appsize in sorted(self.apps.items()):
                print("*",appname, "is using", appsize, "GB")
counter = 0
while True:
    while counter ==0:
        capacity = int(input("Size of your new smartphone (32, 64 or 128 GB): "))
        if capacity not in [32,64,128]:
            print("Invalid, capacity, please try again.")
            continue
        else:
            name = input("Smartphone name: ")
            print("Smart Phone Created!")
            phone = Smartphone(capacity, name)
            counter+=1
            break        
    while True:
        choice = input("(r)eport, (a)dd app, r(e)move app or (q)uit: ")
        if choice == "r":
            phone.report()
        elif choice == "a":
            appname = input("App name to add: ")
            appsize = int(input("App size in GB: "))
            phone.add_app(appname, appsize)
        elif choice == "e":
            appname = input("App name to remove: ")
            phone.remove_app(appname)
        elif choice == "q":
            print("Goodbye!")
            break
        else:
            print("Invalid input. Please try again.")
