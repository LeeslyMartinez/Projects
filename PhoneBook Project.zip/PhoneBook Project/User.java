import java.util.Scanner;

public class User {
	private String username;
	private String password;
	
	public User(String user, String pass) {
		this.username=user;
		this.password=pass;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void PrintUserInfo() {
		System.out.println("Username: "  + username);
		System.out.println("Password: " + password);
	}
}



// 	THIS IS NORMAL USER
 class NormalUser extends User implements Normal{
	 private int id;
	 static Scanner input=new Scanner (System.in);
	 private PhoneBookDirectory y = new PhoneBookDirectory();
	 public NormalUser(String username, String password, int ID) {
			super(username,password);
			this.id= ID;
			
	 }
	 public void PrintUserInfo() {
			System.out.println("Username: "  + super.getUsername());
			System.out.println("Password: " + super.getPassword());
			System.out.println("ID: " +  id);
			System.out.println("Phone Book Directory");
			System.out.println();
			y.PrintAll();
		}
	 public void SortId() {
			y.SortId();
		}
		public int Edit(String first, String last) {
			return y.Edit(first, last);
		}
		
		public int LinearSearchByPhoneNumber(String phone) {
			return y.LinearSearchByPhoneNumber(phone);
		}
		public int addEntry(PhoneBookEntry entry) {
			return y.addEntry(entry);
		}
		public void Menu() {
			int choice;
			String first;
			String last;
			int ID;
			String emad;
			int zip;
			String phone;
			do {
				System.out.println("1. Add a phone entry");
				System.out.println("2. Edit a phone entry of a with a given first name and last name");
				System.out.println("3. Sort the PhoneBookDirectory");
				System.out.println("4. Search using linear search");
				System.out.println("5. Print user's info");
				System.out.println("6. Exit");
				choice =input.nextInt();
				if(choice == 1) {
					System.out.println("Add an entry");
					System.out.println("1. Use default settings");
					System.out.println("2. Add the first name and phone number");
					System.out.println("3. Add in all attributes");
					int ch = input.nextInt();
					if (ch == 1) {
						PhoneBookEntry holder=new PhoneBookEntry();
						System.out.println(addEntry(holder));
					}else if (ch == 2) {
						System.out.print("Enter a first name: ");
						first=input.next();
						System.out.print("Enter a phone number: ");
						last=input.next();
						PhoneBookEntry holder=new PhoneBookEntry(first,last);
						System.out.println(addEntry(holder));
					}else if (ch == 3) {
						System.out.print("Enter a first name: ");
						first=input.next();
						System.out.print("Enter a last name: ");
						last=input.next();	
						System.out.print("Enter an id: ");
						ID=input.nextInt();
						System.out.print("Enter the email address: ");
						emad=input.next();
						System.out.print("Enter the zipcode: ");
						zip=input.nextInt();
						System.out.print("Enter the phone number: ");
						phone=input.next();
						PhoneBookEntry holder=new PhoneBookEntry(ID, first,last,emad,zip,phone);
						System.out.println(addEntry(holder));
					}else {
						System.out.println("Invalid choice");
					}
				}else if (choice == 2) {
					System.out.print("Enter a first name of the entry you want to edit: ");
					first=input.next();
					System.out.print("Enter a last name of the entry you want to edit: ");
					last=input.next();
					System.out.println(Edit(first, last));
				}else if (choice == 3) {
					SortId();
				}else if (choice == 4) {
					System.out.print("Enter the phone number you want to search for: ");
					phone=input.next();
					System.out.println(LinearSearchByPhoneNumber(phone));
				}else if (choice == 5) {
					PrintUserInfo();
				}else if(choice <1 && choice > 6){
					System.out.println("Invalid selection");
				}
			}while(choice != 6);
		}		
	
}
 
 
 
 
 
 
 
 // THIS IS ADMIN
 class PhoneBookAdmin extends User implements Admin{
		private String email;
		 
		static Scanner input=new Scanner (System.in);
		private PhoneBookDirectory y = new PhoneBookDirectory();
		public PhoneBookAdmin(String username, String password, String email) {
			super(username,password);
			this.email= email;
			
		}
		
		
		// PrintUserInfo overridden
		public void PrintUserInfo() {
			System.out.println("Username: "  + super.getUsername());
			System.out.println("Password: " + super.getPassword());
			System.out.println("Email Address " +  email);
			System.out.println("Phone Book Directory entries:");
			System.out.println();
			y.PrintAll();
		}
		
		public void SortId() {
			y.SortId();
		}
		public int Edit(String first, String last) {
			int xy =y.Edit(first, last);
			if (xy==1) {
				return 1;
			}else {
				return 0;
			}
		}
		public int DeleteEntry(int id) {
			int xy= y.DeleteEntry(id);
			if (xy==1) {
				return 1;
			}else {
				return 0;
			}
		}
		public int LinearSearchByPhoneNumber(String phone) {
			return y.LinearSearchByPhoneNumber(phone);
			
		}
		public int addEntry(PhoneBookEntry entry) {
			
			int xy = y.addEntry(entry);
			if (xy==1) {
				return 1;
			}else {
				return 0;
			}
			
			
		}
		public void ChangePass(String pass) {
			super.setPassword(pass);
		}
		public void ChangeUser(String user) {
			super.setUsername(user);
		}
		public PhoneBookEntry SearchbyIdBinarySearch(int ID) {
			y.SortId();
			return y.SearchbyIdBinarySearch(ID);
			
			
			
			
		}
		public void Menu() {
			int choice;
			String first;
			String last;
			int ID;
			String emad;
			int zip;
			String phone;
			do {
				System.out.println("1. Add a phone entry");
				System.out.println("2. Edit a phone entry of a with a given first name and last name");
				System.out.println("3. Delete a phone entry of a given first name and last name");
				System.out.println("4. Sort the PhoneBookDirectory");
				System.out.println("5. Search using linear search");
				System.out.println("6. Search using binary search");
				System.out.println("7. Print admin's info");
				System.out.println("8. Change password");
				System.out.println("9. Change Username");
				System.out.println("10. Exit");
				choice =input.nextInt();
				if(choice == 1) {
					System.out.println("Add an entry");
					System.out.println("1. Use default settings");
					System.out.println("2. Add first name and phone number");
					System.out.println("3. Add all attributes");
					int ch = input.nextInt();
					if (ch == 1) {
						PhoneBookEntry holder=new PhoneBookEntry();
						System.out.println(addEntry(holder));
					}else if (ch == 2) {
						System.out.print("Enter a first name: ");
						first=input.next();
						System.out.print("Enter a phone number: ");
						last=input.next();
						PhoneBookEntry holder=new PhoneBookEntry(first,last);
						System.out.println(addEntry(holder));
					}else if (ch == 3) {
						System.out.print("Enter a first name: ");
						first=input.next();
						System.out.print("Enter a last name: ");
						last=input.next();	
						System.out.print("Enter an id: ");
						ID=input.nextInt();
						System.out.print("Enter the email address: ");
						emad=input.next();
						System.out.print("Enter the zipcode: ");
						zip=input.nextInt();
						System.out.print("Enter the phone number: ");
						phone=input.next();
						PhoneBookEntry holder=new PhoneBookEntry(ID, first,last,emad,zip,phone);
						System.out.println(addEntry(holder));
					}else {
						System.out.println("Invalid choice");
					}
				}else if (choice == 2) {
					System.out.print("Enter a first name of the entry you want to edit: ");
					first=input.next();
					System.out.print("Enter a last name of the entry you want to edit: ");
					last=input.next();
					System.out.println(Edit(first, last));
				}else if (choice == 3) {
					System.out.print("Enter the first name of the entry you want to delete: ");
					first=input.next();
					System.out.print("Enter the last name of the entry you want to delete: ");
					last = input.next();
					PhoneBookEntry [] place=y.getX();
					for (int i=0; i < place.length; i++) {
						if (place[i] ==null) {
							System.out.println("0");
							break;
						}else if (place[i].getLastName() == null || place[i].getLastName()== null) {
							System.out.println("0");
							break;
						}else if (place[i].getFirstName().equalsIgnoreCase(first) && place[i].getLastName().equalsIgnoreCase(last)) {
							int hold=place[i].getId();
							System.out.println(DeleteEntry(hold));
							break;
						}
					}
					
				}else if (choice == 4) {
					SortId();
				}else if (choice == 5) {
					System.out.print("Enter the phone number you want to search for: ");
					phone=input.next();
					System.out.println(LinearSearchByPhoneNumber(phone));
				}else if (choice == 6) {
					System.out.print("Enter an ID: ");
					ID=input.nextInt();
					PhoneBookEntry hold = y.SearchbyIdBinarySearch(ID);
					if (hold == null) {
						System.out.println("ID: " + 0);
						System.out.println("First name: " + "null");
						System.out.println("Last name: " + "null");
						System.out.println("Email: " + "null");
						System.out.println("Zip code: " + 0);
						System.out.println("Phone number: " + "null");
						System.out.println();
					}else {
						hold.printBookEntry();
						System.out.println();
					}
					
				}else if (choice == 7) {
					PrintUserInfo();
				}else if (choice == 8) {
					System.out.println("Enter your new password: ");
					String pass= input.next();
					ChangePass(pass);
				}else if (choice == 9) {
					System.out.println("Enter your new username: ");
					String user= input.next();
					ChangeUser(user);
				}else if (choice <1){
					System.out.println("Invalid selection");
				}
			}while(choice != 10);
		}
		
		
		
	}



