
//CSCI-UA 101, 001
//Haley Hobbs hkh9725, Leesly Martinez lm4569
//import libraries

import java.util.Scanner;
import java.io.*;


public class testingmain {

	public static void main(String[] args) {
		// set scanner
		Scanner input= new Scanner(System.in);
		// declare/initiate variable
		String pass;
		String email;
		String filename;
		// get path from user
		
		System.out.println("Enter file path: ");
		
		filename=input.next();
       
        
		
		int ID;
		String user;
		String [] admin=new String [2];
		String [] normal=new String [2];
		int c=0;
		
		String line=null;
		// open and read file
		try {

			FileReader fileReader = new FileReader(filename);
			
			 BufferedReader bufferedReader = new BufferedReader(fileReader);
			while((line = bufferedReader.readLine()) != null) {
				// print lines in file
				System.out.println(line);
				if(c==0) {
					// first line gets added to the normal array that stores the user + pass
					normal=line.split(",");
					c +=1;
				}else if (c==1) {
					// second line gets added to admin array that stores the user = pass
					admin = line.split(",");
				}
				
				
			}
			bufferedReader.close();
		}
		catch (FileNotFoundException ex) {
			//if file cannot be opened print messages
			System.out.println("Unable to open file " + filename + ".");
		}
		catch (IOException ex) {
			//if error print message
			System.out.println("Error reading file " + filename + ".");
			
		}
		
		
		//initiate variable
		int tries=0;
		
		//enter loop for user login
		while(tries <2) {
			//get username and password from user
			System.out.print("Enter your Username: ");
			user=input.next();
			System.out.print("Enter your password: ");
			pass=input.next();
			// check is the username and password match those from file
			if(user.equals(admin[0]) && pass.equals(admin[1]) ) {
				System.out.println("Welcome back " + admin[0] + "!");
				System.out.print("Please enter in an email address: ");
				email=input.next();
				// creates admin object with input from the user --> opens admin menu
				PhoneBookAdmin holder= new PhoneBookAdmin(user,pass,email);
				holder.Menu();
				break;
			}else if (user.equals(normal[0]) && pass.equals(normal[1])) {
				System.out.println("Welcome back " + normal[0] + "!");
				System.out.print("Please enter in an id: ");
				ID=input.nextInt();
				// creates normal user object with input from the user --> opens normal user menu
				 NormalUser holder2= new NormalUser (user,pass,ID);
				holder2.Menu();
				break;
			}else {
				//if login info are incorrect, increase variable and print message
				tries +=1;
				System.out.println("Unable to login, invalid username/password");
			}
		}
		//limit login attempts to 2
		if (tries ==2) {
			System.out.println("Too many failed login attempts");
		}
		
		input.close();
			
		
			
		
	}

}
