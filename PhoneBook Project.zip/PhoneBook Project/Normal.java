
public interface Normal {
	public void PrintUserInfo();
	public void SortId();
	public int Edit(String first, String last);
	public int LinearSearchByPhoneNumber(String phone);
	public int addEntry(PhoneBookEntry entry);
}

