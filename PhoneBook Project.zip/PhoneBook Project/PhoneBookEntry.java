//CSCI-UA 101, 001
//Haley Hobbs hkh9725

public class PhoneBookEntry {

	//data fields
	private int id;
	private String firstName;
	private String lastName;
	private String email;
	private int zipCode;
	private String phoneNumber;
	
	
	//default constructor
	public PhoneBookEntry() {
		id = -1;
	}
	
	//constructor
	public PhoneBookEntry(int entryId, String entryFirstName, String entryLast, String entryEmail, int entryZip, String entryPhoneNumber) {
		id = entryId;
		firstName = entryFirstName;
		lastName = entryLast;
		email = entryEmail;
		zipCode = entryZip;
		phoneNumber = entryPhoneNumber;
	}
	
	//constructor
	public PhoneBookEntry(String entryFirstName, String entryPhoneNumber) {
		id = -1;
		firstName = entryFirstName;
		phoneNumber = entryPhoneNumber;
	}
	
	public PhoneBookEntry(String entryFirstName) {
		id = -1;
		firstName = entryFirstName;
	}
	
	//display info
	public void printBookEntry() {
		System.out.println("ID: " + getId());
		System.out.println("First name: " + getFirstName());
		System.out.println("Last name: " + getLastName());
		System.out.println("Email: " + getEmail());
		System.out.println("Zip code: " + getZipCode());
		System.out.println("Phone number: " + getPhoneNumber());
	}
	
	//getters and setters
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public int getZipCode() {
		return zipCode;
	}
	
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}


