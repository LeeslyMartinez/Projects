
public interface Admin {
	public void PrintUserInfo();
	public void SortId();
	public int DeleteEntry(int Id);
	public int Edit(String first, String last);
	public int LinearSearchByPhoneNumber(String phone);
	public void ChangePass(String pass);
	public void ChangeUser(String user);
	public PhoneBookEntry SearchbyIdBinarySearch(int ID);
	public int addEntry(PhoneBookEntry entry);
}
