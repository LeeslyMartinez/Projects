import java.util.Scanner;
public class PhoneBookDirectory{
	private PhoneBookEntry [] x = new PhoneBookEntry [6];
	private int size;
	private static Scanner input=new Scanner (System.in);
	
	
	// Add entry -------
	public int addEntry(PhoneBookEntry entry) {
		if (size < x.length) {
			
			x[size] =entry;
			size+=1;
			return 1;
		}else {
			return 0;
		}
	}
	
	
	//Print all info
	public void PrintAll() {
		for (int i=0; i < size;i++) {
			x[i].printBookEntry();
			System.out.println();
		}
	}
	
	
	public PhoneBookEntry[] getX() {
		return x;
	}


	//Search by linear search
	public int LinearSearchByPhoneNumber(String PhoneNumber) {
		for (int i=0; i < size;i++) {
			if(x[i].getPhoneNumber() == null) {
				continue;
			}else if (x[i].getPhoneNumber().equals(PhoneNumber))
				return 1;
		}
		return 0;
	}
	
	
	// Search by binary search
	public PhoneBookEntry SearchbyIdBinarySearch(int id) {
		int start=0; 
		int high = size -1;
		while(start <= high) {
			int mid= start + (high-start)/2;
			 if(x[mid].getId() == id){
				 return x[mid];
			 }else if(x[mid].getId() < id) {
				 start = mid +1;
			 }else {
				 high = mid -1;
			 }
			 
		}
		return x[5];
		
	}
	
	
	//Sort by id
	public void SortId() {
		for (int i =0; i < size; i++) {
			int min=i;
			for (int y=i+1; y < size;y++) {
				if (x[y].getId() < x[min].getId()) {
					min=y;
				}
			}
			PhoneBookEntry placeHolder= x[i];
			x[i] = x[min];
			x[min] = placeHolder;
			
		}
		
	}
	
	
	// Edit entry -------
	public int Edit(String firstName, String lastName) {
		boolean check= false;
		for (int i =0; i < size;i++) {
			if(x[i] == null) {
				continue;
			}else if (x[i].getLastName() == null || x[i].getLastName()== null) {
				continue;
			}else if(x[i].getFirstName().equalsIgnoreCase(firstName) && x[i].getLastName().equalsIgnoreCase(lastName)) {
				int choice=0;
				int num;
				String letter;
				do {
					System.out.println("1. Edit ID");
					System.out.println("2. Edit First Name");
					System.out.println("3. Edit Last Name");
					System.out.println("4. Edit Email");
					System.out.println("5. Edit ZipCode");
					System.out.println("6. Edit Phone Number");
					System.out.println("7. Exit");
					System.out.print("What would you like to edit?");
					choice=input.nextInt();
					if (choice == 1) {
						System.out.println("Enter the new ID");
						num=input.nextInt();
						x[i].setId(num);
						check=true;
					}else if (choice ==2) {
						System.out.println("Enter the new First Name");
						letter=input.next();
						x[i].setFirstName(letter);
						check=true;
					}else if (choice ==3) {
						System.out.println("Enter the new Last Name");
						letter=input.next();
						x[i].setLastName(letter);
						check=true;
					}else if (choice ==4) {
						System.out.println("Enter the new Email");
						letter=input.next();
						x[i].setEmail(letter);
						check=true;
					}else if (choice ==5) {
						System.out.println("Enter the new Zipcode");
						num=input.nextInt();
						x[i].setZipCode(num);
						check=true;
					}else if (choice ==6) {
						System.out.println("Enter the new Phone Number");
						letter=input.next();
						x[i].setPhoneNumber(letter);
						check=true;
					}else if(choice <1 && choice > 7) {
						System.out.println("Invalid selection.");
					}
				}while(choice !=7);
				
			}
		}
		if (check == true) {
			return 1;
		}else {
			return 0;
		}
		}

	// Delete entry -----
	public int DeleteEntry(int id) {
	    for (int i = 0; i < size; i++) {
	        if (x[i].getId() == id) {
	            for (int y = i; y < size - 1; y++) {
	                x[y] = x[y + 1];
	            }
	            x[size - 1] = null;
	            size-=1;
	            return 1;
	        }
	    }
	    return 0;
	}
}